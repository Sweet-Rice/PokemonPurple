package overWorld;

import basicgraphics.Scene;

public interface GlobalFunc {
    public void fly();
    public void respawn();
    public void switchScene(Scene scene);
}
