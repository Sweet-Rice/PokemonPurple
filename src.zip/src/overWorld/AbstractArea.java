package overWorld;

public abstract class AbstractArea {


}
