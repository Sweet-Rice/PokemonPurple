package overWorld;

import basicgraphics.SpriteComponent;

public class mySpriteComponent extends SpriteComponent {



}
