package menuWorld;

import basicgraphics.*;
import basicgraphics.images.Picture;
import basicgraphics.sounds.ReusableClip;
import generic.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.InputStream;

public class Menu {
    //private GameScreen gs;

    public final Card card;

    private SpriteComponent sc;
    private SpriteComponent r;
    private SpriteComponent g;

//menu part
    private Red red;
    private Gary gary;
    private BouncingSprite bouncingsprite;

//save part
    private SaveSprite saveSprite;
    //issue inside the sprite

    private Scene scene;
    private Scene saveScene;
    private Scene beginSequenceScene;
    private LetterHandler topLh1, topLhShadow1, bottomLh1, bottomLhShadow1;

    private int beginProg = 0;


    final ReusableClip titleClip = new ReusableClip("title3.wav");
    //final ReusableClip buttonClip = new ReusableClip("button1.wav");

    GameManager gm;


    public Menu(BasicFrame frame, GameManager gr) {
        card = frame.getCard();
        this.sc = new SpriteComponent(){
        @Override
            public void paintBackground(Graphics g) {
                Dimension d = getSize();
                g.setColor(Color.WHITE);
                g.fillRect(0, 0, d.width, d.height);
            }
        };
        this.r = new SpriteComponent();
        this.g = new SpriteComponent();

        scene=sc.getScene();
        this.beginSequenceScene = sc.getScene();
        saveScene= sc.createScene();
        ClockWorker.initialize(33);
        ClockWorker.addTask(sc.moveSprites());
        //sc.swapScene(scene);

        card.addKeyListener(new KeyAdapter() {
            //int stage = 0;
            @Override
            public void keyPressed(KeyEvent a) {
                System.out.println("caught key");
                if (a.getKeyCode()==KeyEvent.VK_RIGHT) {
                    //initializeBeginSequence();
                    System.out.println("aha");
                    beginProg++;
                }
                if (beginProg == 0) {


                }else if (beginProg == 1) {
                    if (a.getKeyCode() == KeyEvent.VK_Z ){
                        System.exit(0);
                        topLh1.fadeIn(); topLhShadow1.fadeOut();
                    }
                }
            }
        });



        initializeMenu();
        //this.gs = gs;

        this.gm = gr;


    }

    private void initializeMenu() {

        titleClip.loop();

        BasicLayout blayout = new BasicLayout();
        card.add(sc);
        sc.setLayout(blayout);

        //sc.add("x=0,y=0,w=4,h=3",sc);
        sc.add("x=0,y=3,w=1,h=3",r);
        sc.add("x=3,y=3,w=1,h=3",g);

        ClockWorker.addTask(sc.moveSprites());
        ClockWorker.addTask(r.moveSprites());
        ClockWorker.addTask(g.moveSprites());

        bouncingsprite = new BouncingSprite(sc.getScene(), sc);

        red = new Red(r.getScene(), r);
        gary = new Gary(g.getScene(), g);
        //letter = new Letter(sc.getScene(),0,0);


        //test
        InputStream fontStream = getClass().getResourceAsStream("/fonts/pokemon_fire_red.ttf");
        Font font = null;
        try {
            font = Font.createFont(Font.TRUETYPE_FONT, fontStream);
        } catch (FontFormatException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        JLabel title = new JLabel("Purple Version");

        title.setFont(font.deriveFont(Font.BOLD, 50));
        title.setForeground(Color.MAGENTA);
        title.setOpaque(true);
        title.setBackground(Color.WHITE);
        title.setHorizontalAlignment(0);

        sc.add( "x=1,y=3,w=2,h=1", title);

        //card.add("m", title);

        JButton startButton = new JButton("Start");
        sc.add("x=1,y=5,w=2,h=1", startButton);


        startButton.setFont(font.deriveFont(Font.BOLD, 100));

        startButton.setForeground(Color.BLACK);
        startButton.setBackground(Color.white);
        startButton.setBorderPainted(false);


        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                //  buttonClip.playOverlapping();

                //titleClip.stop();
                //optimally shouldn't need to do all this. will figure out eventually
                //

                //
                sc.remove(startButton);
                sc.remove(g);
                sc.remove(r);
                sc.remove(title);

                ClockWorker.addTask(new Task(50){
                    TransitionSprite spr = new TransitionSprite(sc.getScene(),1);
                    @Override
                    public void run() {
                        if (iteration()==0){

                            spr.transition(true, 1);
                        }
                        if (iteration()==20){
                            spr.destroy();
                            //initializeBeginSequence();
                            gm.switchGame();
                            //initializeSaveSc();
                            //initializeBeginSequence();
                        }
                    }
                });



            }
        });





    }
    private void initializeBeginSequence() {
        sc.swapScene(beginSequenceScene);
        sc.setPreferredSize(new Dimension(900, 600));

        System.out.println(sc.getPreferredSize().width + " "+ sc.getPreferredSize().height);
       TransitionSprite transitionSprite = new TransitionSprite(beginSequenceScene,1);
        transitionSprite.transition(false, 1);
        Sprite introBox = new Sprite(beginSequenceScene);
        introBox.setDrawingPriority(1);

        introBox.setPicture(new Picture("introBox.png"));
        MenuChu chu = new MenuChu(beginSequenceScene);

        InputStream fontStream = getClass().getResourceAsStream("/fonts/pokemon_fire_red.ttf");
        Font font = null;
        try {
            font = Font.createFont(Font.TRUETYPE_FONT, fontStream);
        } catch (FontFormatException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        font = font.deriveFont(Font.PLAIN, 57);
        int grayOffset = 60;
        String string1 = "In the world which you are about to enter, you will embark on a " +
                "grand adventure with you as the hero.";
        Color gray = new Color(90,90,90);
        topLh1 = new LetterHandler(40, 140, 820, 200,sc,font, gray,string1,50 );
        topLhShadow1 = new LetterHandler(43, 142, 800, 200,sc,font, Color.lightGray,string1,49);
        topLh1.fadeIn(); topLhShadow1.fadeIn();

        String string2 = "Speak to people and check things " +
                "wherever you go, be it towns, roads, " +
                "or caves. Gather information and" +
                " hints from every source.";
        bottomLh1 = new LetterHandler(40, 350, 820, 300,sc,font, gray,string2,50);
        bottomLhShadow1 = new LetterHandler(43, 352, 820, 300,sc,font, Color.lightGray,string2,49);
        bottomLh1.fadeIn(); bottomLhShadow1.fadeIn();




    }
    private void progressBegin(){

    }
    private void initializeSaveSc(){
        //Picture white = new Picture("white.jpg");
        //white.setBackground(Color.white);
        //saveScene.setPainter(new BackgroundPainter( white));
        sc.swapScene(saveScene);
        saveSprite = new SaveSprite(saveScene, sc);

        TransitionSprite transitionSprite = new TransitionSprite(saveScene,1);
        transitionSprite.transition(false, 1);
        ClockWorker.initialize(33);
        ClockWorker.addTask(sc.moveSprites());
        BasicLayout blayout1 = new BasicLayout();

        ClockWorker.addTask(new Task(50){

            @Override
            public void run() {
                if (iteration()==50)saveSprite.getLh().fadeOut();
            }
        });

    }
    public void keyAction(KeyEvent e){
        System.out.println("caught key");
        if (e.getKeyCode()==KeyEvent.VK_RIGHT) {
            //initializeBeginSequence();
            System.out.println("aha");
            beginProg++;
        }
        if (beginProg == 0) {


        }else if (beginProg == 1) {
            if (e.getKeyCode() == KeyEvent.VK_Z ){
                System.exit(0);
                topLh1.fadeIn(); topLhShadow1.fadeOut();
            }
        }
    }
}